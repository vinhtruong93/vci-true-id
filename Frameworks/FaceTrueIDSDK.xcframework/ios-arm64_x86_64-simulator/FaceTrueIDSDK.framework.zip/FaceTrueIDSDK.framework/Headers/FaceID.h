//
//  FaceID.h
//  FaceID
//
//  Created by Vu Nguyen Kha on 10/21/19.
//  Copyright © 2019 VNG. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FaceID.
FOUNDATION_EXPORT double FaceIDVersionNumber;

//! Project version string for FaceID.
FOUNDATION_EXPORT const unsigned char FaceIDVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FaceID/PublicHeader.h>


